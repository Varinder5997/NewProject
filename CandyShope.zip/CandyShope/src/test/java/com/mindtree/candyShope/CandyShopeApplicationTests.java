package com.mindtree.candyShope;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CandyShopeApplicationTests {

	@Test
	void contextLoads() {
	}

}
