package com.mindtree.candyShope;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CandyShopeApplication {

	public static void main(String[] args) {
		SpringApplication.run(CandyShopeApplication.class, args);
	}

}
